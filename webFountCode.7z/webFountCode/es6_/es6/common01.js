//演示 es6导入模块
let name = "name";

 function run () {
    return name + "跑";
}

//第一种导出方式

export {
    name,
    run
}