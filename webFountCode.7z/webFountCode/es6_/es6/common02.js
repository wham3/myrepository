//演示 es6导入模块
export let name = "name";

export function run() {
    return name + "跑";
}

//第二种导出方式

