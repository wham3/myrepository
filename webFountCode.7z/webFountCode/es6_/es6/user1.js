//演示引入模块

//第一种方式
import {name,run} from "./common01.js"


function f() {
    console.log("name:",name);
    console.log("run",run);
}
f();