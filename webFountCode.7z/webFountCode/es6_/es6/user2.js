//演示引入模块

//第二种方式
import {name,run} from "./common01.js"


console.log("name:",name);
console.log("run:",run());

